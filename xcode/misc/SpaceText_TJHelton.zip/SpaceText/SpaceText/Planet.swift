//
//  Planet.swift
//  SpaceText
//
//  Created by T.J. Helton on 9/7/16.
//  Copyright © 2016 Your School. All rights reserved.
//

import Foundation

class Planet {
    let name: String
    let description: String
    
    init(name: String, description: String) {
        self.name = name
        self.description = description
    }
}