//
//  File.swift
//  SpaceText
//
//  Created by T.J. Helton on 9/2/16.
//  Copyright © 2016 Your School. All rights reserved.
//

import Foundation

class SpaceAdventure {
    
    var planetarySystem = PlanetarySystem(name: "Solar System", planets: [Planet]())
    
    init(planetarySystem: PlanetarySystem) {
        self.planetarySystem = planetarySystem
    }
    

    
    private func displayIntroduction() {
        print ("Welcome to the \(planetarySystem.name)!")
        print("there are \(planetarySystem.planets.count) planets to explore.")
    }
    func start() {
        displayIntroduction()
        greetAdventurer()
        if (!planetarySystem.planets.isEmpty) {
            print("lets go on an adventure")
            determineDestination()
        }
    }
    private func responseToPrompt (prompt: String) -> String {
        print(prompt)
        return getln()
    }
    private func visit(planetName: String) {
        print("traveling to \(planetName)...")
    }
    private func greetAdventurer () {
        let name = responseToPrompt("what is your name?")
        print("Nice to meet you, \(name) . My name is Eliza. I'm an old friend of Siri")
        print("let's go on an adventure!")
    }
    
    private func determineDestination() {
        var decision = "" //start with empty string
        while !(decision == "Y" || decision == "N") {
            decision = responseToPrompt("shall i choose? (Y or N)")
            if decision == "Y" {
                if let planet = planetarySystem.randomPlanets {
                    visit(planet.name)
                } else {
                    print("there are no planets in this system.")
                }
            } else if (decision == "N") {
                let planetName = responseToPrompt("Ok, name the planet you would like to visit.")
                visit(planetName)
                for planet in planetarySystem.planets {
                if planetName == planet.name {
                        print("arrived at \(planet.name). \(planet.description)")
                    }
                }
            } else {
                print("That wasn't a valid response")
                
            }
        }
    }
}