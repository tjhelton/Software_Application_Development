import Foundation


let planetData = [
    "Mercury": "a very hot planet closest to the sun",
    "Earth": "the planet that we live on",
    "Venus": "i do not know what this planet is like",
    "Jupiter": "i do not know what this planet is like",
    "Mars": "this planet is rocky",
    "saturn": "this planet has rings",
    "uranus": "i do not know what this planet is like",
    "neptune": "a cold planet, furthest from the sun"
]

let systemName = "Solar System"
let planets = planetData.map {
    name, description in Planet(name: name, description: description)
}

let solarSystem = PlanetarySystem(name: systemName, planets: planets)
let adventure = SpaceAdventure(planetarySystem: solarSystem)
adventure.start()



