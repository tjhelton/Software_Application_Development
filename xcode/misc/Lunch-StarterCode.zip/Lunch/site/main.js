$(document).ready(function() {
  $('#todaysdate').text("Today is " + moment().format('MMMM D, YYYY'));
});


